package Eggs;
//*******************************************
// Program Name: Eggs
// Author: Aleisha Mari-Vializ
// Description: A program that prompts a user for the number of eggs +
// in the order and then display the amount owed with a full explanation. 
//******************************************
import java.util.Scanner; 

public class Eggs {
    public static void main(String[] args) {
        
    final double DOZEN_PRICE = 3.25; 
    final double SINGLE_EGG_PRICE = 0.45;
    final int EGGS_PER_DOZEN = 12;

 
Scanner scanner = new Scanner(System.in);

     
    System.out.print("Enter the number of eggs you want to order: ");
        int eggsOrdered = scanner.nextInt();

   
    int dozens = eggsOrdered / EGGS_PER_DOZEN;
    int looseEggs = eggsOrdered % EGGS_PER_DOZEN;

  
    double totalCost = (dozens * DOZEN_PRICE) + (looseEggs * SINGLE_EGG_PRICE);


System.out.println("You ordered " + eggsOrdered + " eggs.");
System.out.println("That’s " + dozens + " dozen at $" + DOZEN_PRICE + " per dozen" +
       " and " + looseEggs + " loose eggs at " + (int)(SINGLE_EGG_PRICE * 100) +
       " cents each for a total of $" + String.format("%.2f", totalCost) + ".");

   
    scanner.close();
    }
}