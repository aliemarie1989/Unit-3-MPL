package Percentages;
//*******************************************
// Program Name: Percentages
// Author: Aleisha Mari-Vializ
// Description: Main method holds two double variables, and prompt the user for values. 
//******************************************
import java.util.Scanner; 

public class Percentages {
    public static void main(String[] args) {
       
Scanner scanner = new Scanner(System.in);

    System.out.print("Enter the first number: ");
    double num1 = scanner.nextDouble();

    System.out.print("Enter the second number: ");
    double num2 = scanner.nextDouble();

    
    computePercent(num1, num2);
    computePercent(num2, num1);

        scanner.close();
    }
    
    public static void computePercent(double value1, double value2) {
        double percentage = (value1 / value2) * 100; 
        System.out.println(value1 + " is " + String.format("%.2f", percentage) + "% of " + value2);
    }
}